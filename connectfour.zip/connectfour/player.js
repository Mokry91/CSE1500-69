module.exports = function Player(id) {
    this.id = id;
    this.nr = 0;
    this.oponent = 0;
    this.con = null;
    this.turn = false;
}