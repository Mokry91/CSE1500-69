var width = $(window).width();
var height = $(window).height();
if (width < 800) {
    alert("Your screen is too small and the gameplay will not be optimal.");
}